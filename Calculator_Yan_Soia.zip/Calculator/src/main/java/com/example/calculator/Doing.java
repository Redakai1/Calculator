package com.example.calculator;

public class Doing {
    public static int firstI = 0;
    public static int secondI = 0;

    public static String calculate(String first, String second, String operationText){
        int ans = 0;
        try {
            firstI = Integer.valueOf(first);
            secondI = Integer.valueOf(second);
        } catch (NumberFormatException nfe){
            System.out.println("NumberFormatException: Cannot parse null string");
        }

        switch(operationText){
            case "+" -> ans = firstI + secondI;
            case "-" -> ans = firstI - secondI;
            case "*" -> ans = firstI * secondI;
            case "/" -> ans = firstI / secondI;
            case "^" -> ans = (int) Math.pow(firstI, secondI);
            case "√" -> ans = (int) Math.sqrt(firstI);
        }
        return Integer.toString(ans);
    }
}
